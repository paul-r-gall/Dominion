public interface Function {
	public void fun(Player currentPlayer, Dominion status);
}